﻿Public Class Charity

    Private ISThersEnoughPrpForelections As Boolean
    Private ClubProfit As Double





End Class
