﻿Public Class frmElectionCenter

    Private Sub frmElectionCenter_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form1.Members(3).ll = hjhyh
    End Sub
End Class